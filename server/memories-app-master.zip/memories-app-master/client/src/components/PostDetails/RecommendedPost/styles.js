import { makeStyles } from "@material-ui/core/styles";

export default makeStyles(() => ({
  paper: {
    cursor: "pointer",
    borderRadius: 0,
    padding: "20px",
  },
}));
