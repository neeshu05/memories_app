# memories-app
An application to share your memories with other people. Created using React.js, Node.js, Redux, Express, MongoDB, Mongoose and MUI.

## How to start
Open both client and server folders in your console and in each one run `npm start`.
